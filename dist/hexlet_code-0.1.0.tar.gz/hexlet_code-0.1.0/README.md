### Hexlet tests and linter status:
[![Actions Status](https://github.com/by-sitnikov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/by-sitnikov/python-project-49/actions)

### Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/3d08c8889e90d8129a75/maintainability)](https://codeclimate.com/github/by-sitnikov/python-project-49/maintainability)


## brain-even
[![asciicast](https://asciinema.org/a/549496.svg)](https://asciinema.org/a/549496)